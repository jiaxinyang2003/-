import { Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import Intro from "./pages/Intro";
import Test from "./pages/Test";
import MIS from "./pages/MIS";
import Resume from "./pages/Resume";

export default function App() {
  return (
    <div className="p-4 max-w-4xl mx-auto">
      <nav className="flex gap-4 bg-blue-100 p-4 rounded-xl mb-6">
        <Link to="/">首頁</Link>
        <Link to="/intro">個人簡介</Link>
        <Link to="/test">測驗結果</Link>
        <Link to="/mis">MIS 工作分析</Link>
        <Link to="/resume">求職履歷</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/intro" element={<Intro />} />
        <Route path="/test" element={<Test />} />
        <Route path="/mis" element={<MIS />} />
        <Route path="/resume" element={<Resume />} />
      </Routes>
    </div>
  );
}