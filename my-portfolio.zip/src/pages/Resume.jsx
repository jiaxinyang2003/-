export default function Resume() {
  return (
    <div>
      <h2>求職履歷</h2>
      <p>技術客服 / IT 客服支援的工作內容與未來發展...</p>
    </div>
  );
}