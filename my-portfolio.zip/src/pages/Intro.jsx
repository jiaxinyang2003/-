export default function Intro() {
  return (
    <div>
      <h2>個人簡介</h2>
      <p>姓名: 楊佳欣</p>
      <p>系級: 企管三B</p>
      <p>學號: 411139167</p>
      <p>信箱: yangj850@gmail.com</p>
    </div>
  );
}