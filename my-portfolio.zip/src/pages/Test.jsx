export default function Test() {
  return (
    <div>
      <h2>我的測驗結果</h2>
      <p>興趣何倫碼源自心理學家 John Holland 的生涯類型論...</p>
    </div>
  );
}