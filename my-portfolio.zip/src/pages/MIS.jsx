export default function MIS() {
  return (
    <div>
      <h2>MIS 工作分析</h2>
      <p>R - 實做型、S - 社會型的相關職位說明...</p>
    </div>
  );
}